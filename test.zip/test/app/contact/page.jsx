const Contact = () => {
    return <div>contat page</div>;
};
    
    export default Contact;